const express = require('express');

const { registerPage, loginPage, loginUser, registeruser, dashPage } = require('../controllers/authController');

const routes = express.Router();

const passport = require('passport')

routes.get('/register', registerPage);

routes.get('/', loginPage);

routes.post('/loginuser',passport.authenticate('local', {failureRedirect : '/'}), loginUser);

routes.post('/registeruser', registeruser);

routes.get('/dashboard', dashPage)

module.exports = routes;