const adminModel = require('../model/adminModel');

const loginPage = (req, res) => {
    return res.render('login');
}

const registerPage = (req, res) => {
    return res.render('register');
}

const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await adminModel.findOne({ email: email });

        if(!user || user.password != password ){
            console.log('invalid email or password');
            return res.redirect('/')
        }
        return res.redirect('/dashboard');
    } catch (err) {
        console.log(err);
        return false;
    }
}

const registeruser = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        await adminModel.create({
            name: name,
            email: email,
            password: password
        });

        console.log('data registered !');
        return res.redirect('/')

    } catch (err) {
        console.log(err);
        return false;
    }
}

const dashPage = (req, res) => {
    return res.render('dashboard');
}

module.exports = {
    loginPage,
    registerPage,
    registeruser,
    dashPage,
    loginUser
}